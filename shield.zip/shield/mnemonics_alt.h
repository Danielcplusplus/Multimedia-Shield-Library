//Multimedia Shield opcode mnemonics header
//WARNING: Based on temporary specs v0.01a

//System opcodes
#define PING 0x0000
#define BOOT 0x01
#define INFO 0x02
#define SETBAUD 0x03
#define SETLED 0x04
#define REGST 0x05
#define REGAND 0x06
#define REGOR 0x07
#define REGXOR 0x08
#define REGNEG 0x09
#define REGSL 0x0A
#define REGSR 0x0B
#define REGLD 0x0C

//Memory management opcodes
#define MAL 0x0D
#define MRAL 0x0E
#define MDAL 0x0F
#define MLD 0x10
#define MST 0x11
#define MLSTR 0x12
#define MSSTR 0x13

//Audio opcodes
#define AEN 0x14
#define ABUF 0x15
#define ASAM 0x16
#define ACH 0x17
#define ACHV 0x18
#define ACHENV 0x19
#define ACHG 0x1A
#define ACHT 0x1B
#define ACHPT 0x1C
#define ACHR 0x1D
#define ACHSW 0x0000
#define ACST 0x0000
#define ACSD 0x0000
#define ACSW 0x0000
#define ACSF 0x0000
#define ACC 0x0000

//Tracker opcodes
#define ATREN 0x1E
#define ATRML 0x1F
#define ATRMC 0x20

//Video opcodes
#define VMODE 0x30
#define VCLR 0x31
#define VPRINT 0x32
#define VPOS 0x33
#define VDL 0x34
#define VDR 0x35
#define VDD 0x36
#define VTL 0x37
#define VTD 0x38
#define VTDW 0x39
#define VDDX 0x40
#define VDRF 0x41
#define VLT 0x0000
#define VDTS 0x0000


//Response opcodes
#define ROK 0xF0
#define RFAIL 0xF1
#define RINC 0xF3
#define RDBG 0xF4
#define RUNK 0xF5

//Miscellaneous / prefixes
#define BEX 0xFF



//Emergency, non-standard bytecodes
