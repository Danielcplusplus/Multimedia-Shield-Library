#include "shield_lib.h"
#include <stdarg.h>
#include <SoftwareSerial.h>
#include "mnemonics.h"

int device_i = 0;
SoftwareSerial shield_serial(4,5);
void shield :: shield_send(){
}


void shield_recv(byte *ptr){

}
void send_opcode(uint16_t opcode_int_send){
    union
    {
        uint16_t opcode_int;
        uint8_t  opcode_bytes[2];
    };

    opcode_int_send = opcode_int;
    shield_serial.write(byte(opcode_bytes[0]));
    shield_serial.write(byte(opcode_bytes[1]));
}
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
shield :: shield(){}
uint8_t shield::audio::ch_create() {
    send_opcode(ACC);
    uint8_t buffer;
    buffer = uint8_t(shield_serial.read());
}
int shield::audio::ch_destroy(uint8_t channel) {
    send_opcode(ACD);
    shield_serial.write(byte(channel));
}
int shield::audio::ch_set_duty(uint8_t channel, int duty) {
    send_opcode(ACSD);
    shield_serial.write(byte(channel));
    shield_serial.write(byte(duty));

}
int shield::audio::ch_set_type(uint8_t channel, int type) {
    send_opcode(ACST);
    shield_serial.write(byte(channel));
    shield_serial.write(byte(type));

}
int shield::audio::ch_set_waveform(uint8_t channel, int waveform) {
    send_opcode(ACSW);
    shield_serial.write(byte(channel));
    shield_serial.write(byte(waveform));

}

int shield::audio::ch_set_frequency(uint8_t channel, int frequency){
    send_opcode(ACSF);
    shield_serial.write(byte(channel));
    i_writeint(frequency,2);
}

//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

int shield::video::print(char *str){
    send_opcode(VLT);
    shield_serial.write(byte(0));//Loading tile-set
    shield_serial.write(byte(0));//Choosing tile-set(16bit)-->
    shield_serial.write(byte(0));
    send_opcode(VDTS);
    shield_serial.print(str);
    if(!wait_for_ok(1000))return 0;
    return 1;
}
int shield::video::init(int width, int height, unsigned char color_depth){
    send_opcode(VMODE);
    i_writeint(width, 2);
    i_writeint(height, 2);
    shield_serial.write(byte(color_depth));
    if(!wait_for_ok(1000))return 0;
    return 1;
}
int shield::video::cursor(int xpos, int ypos){
    send_opcode(VPOS);
    i_writeint(xpos, 2);
    i_writeint(ypos, 2);
    if(!wait_for_ok(1000))return 0;
    return 1;
}
int shield::video::cls(){
    send_opcode(VCLR);
    if(!wait_for_ok(1000))return 0;
    return 1;
}
int shield::video::dot(int xpos, int ypos, long color){
    send_opcode(VDD);
    i_writeint(xpos, 2);
    i_writeint(ypos, 2);
    i_writeint(color, 3);
    if(!wait_for_ok(1000))return 0;
    return 1;
}
int shield::video::dot_xor(int xpos, int ypos){
    send_opcode(VDDX);
    i_writeint(xpos, 2);
    i_writeint(ypos, 2);
    if(!wait_for_ok(1000))return 0;
    return 1;
}
int shield::video::line(int xpos1, int ypos1, int xpos2, int ypos2, long color){
    send_opcode(VDL);
    i_writeint(xpos1, 2);
    i_writeint(ypos1, 2);
    i_writeint(xpos2, 2);
    i_writeint(ypos2, 2);
    i_writeint(color, 3);
    if(!wait_for_ok(1000))return 0;
    return 1;
}

int shield::video::rectangle(int xpos1, int ypos1, int xpos2, int ypos2, long color){
  send_opcode(VDR);
  i_writeint(xpos1, 2);
  i_writeint(ypos1, 2);
  i_writeint(xpos2, 2);
  i_writeint(ypos2, 2);
  i_writeint(color, 3);
  if(!wait_for_ok(1000))return 0;
  return 1;

}
int shield::video::rectangle_filled(int xpos1, int ypos1, int xpos2, int ypos2, long color){
  send_opcode(VDRF);
  i_writeint(xpos1, 2);
  i_writeint(ypos1, 2);
  i_writeint(xpos2, 2);
  i_writeint(ypos2, 2);
  i_writeint(color, 3);
  if(!wait_for_ok(1000))return 0;
  return 1;

}
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
int shield::begin(int BAUD){
    shield_serial.begin(BAUD);
}

int wait_for_ok(unsigned long timeout)
{
    timeout += millis();
    while(timeout > millis())
    {
        if(shield_serial.available() > 0)
        {
            if(shield_serial.read() == ROK)return 0;
        }
    }
    return 1;
}

void i_writeint(long a, int bytes)
{
    if(bytes > 0)
    {
        while(bytes)
        {
            shield_serial.write(((a >> (8*(bytes-1))) & 255));
            bytes--;
        }
    }
}
int ping(int retries)
{
    send_opcode(PING);
    while(retries--)if(!wait_for_ok(500))return 0;
    return 1;
}
int reboot()
{
   send_opcode(BOOT);
    shield_serial.write(byte(0));
    if(!wait_for_ok(500))return 0;
    return 1;
}
int setbaud(int rate)
{
    send_opcode(SETBAUD);
    i_writeint(rate,2);
    if(!wait_for_ok(1000))return 0;
    shield_serial.end();
    shield_serial.begin(rate);
    return 1;
}
