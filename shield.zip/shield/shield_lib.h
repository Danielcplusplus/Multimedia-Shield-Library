#ifndef shield_lib
#define shield_lib
#include <Arduino.h>
#include <stdarg.h>
#include <SoftwareSerial.h>

void shield_recv();
int reboot();
int setbaud(int rate);
int ping(int retries);
int wait_for_ok(unsigned long timeout);
void i_writeint(long a, int bytes);
class shield
{
public:
  shield();
  int begin(int BAUD);
  void shield_send();
  class audio
  {
  public:
      uint8_t ch_create();
      int ch_destroy(uint8_t channel);
      int ch_set_type(uint8_t channel, int type);
      int ch_set_frequency(uint8_t channel, int frequency);
      int ch_set_waveform(uint8_t channel, int waveform);
      int ch_set_duty(uint8_t channel, int duty);
      void shield_send(char *str, unsigned char pin);


  };
 audio audio;

 class video
 {
 public:
     int print(char *str);
     int init(int width, int height, unsigned char color_depth);
     int cursor(int xpos, int ypos);
     int cls();
     int dot(int xpos, int ypos, long color);
     int dot_xor(int xpos, int ypos);
     int line(int xpos1, int ypos1, int xpos2, int ypos2, long color);
     int rectangle(int xpos1, int ypos1, int xpos2, int ypos2, long color);
     int rectangle_filled(int xpos1, int ypos1, int xpos2, int ypos2, long color);
 };
video video;

private:
    int _pin;
    int _state;
    int _device;


};
#endif
